const express = require('express')
const bodyParser = require('body-parser')
const app = express()

const authenticationRoute = require('./routes/authentication')

const craftbeersRoute = require('./routes/craftbeers')
const craftbreweriesRoute = require('./routes/craftbreweries')
const searchRoute = require('./routes/search')

const usersRoute = require('./routes/users')
const userfavoriteRoute = require('./routes/userfavorites')


// Set correct port based on enviorment
const normalizePort = val => {
    var port = parseInt(val, 10);

    if (isNaN(port)) {
        // named pipe
        return val;
    }

    if (port >= 0) {
        // port number
        return port;
    }

    return false;
};

const port = normalizePort(process.env.PORT || "3000");
app.set("port", port);

// Add headers for access
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'Origin, X-Request-With, Content-Type, Accept, Authorization'
    );
    res.setHeader(
        'Access-Control-Allow-Methods',
        'GET, POST, PATCH, DELETE, OPTIONS'
    );
    next();
});

// Parsing middleware
app.use(bodyParser.json())
app.use(
    bodyParser.urlencoded({
        extended: false,
    })
)

// Checking nodejs server 
app.get('/', (request, response) => {
    response.json({ info: 'Node.js, Express, and Postgres API' })
})

// Postgres
//
// Restricted (Authenticate user before allowing access)
app.get('/login', authenticationRoute.loginAuth)

// 
// Searching
// 
app.get('/search/:term', searchRoute.getBeerBrewerySearch)

// 
// Craft Beer Table
//
app.get('/craftbeers/id/:id', craftbeersRoute.getCraftBeerByID)
app.get('/craftbeers/search/:name', craftbeersRoute.getCraftBeerByName)
app.get('/craftbeers/:limit/:offset', craftbeersRoute.getCraftBeers)
app.get('/craftbeers', craftbeersRoute.getCraftBeersAll)
app.get('/craftbeers/styles', craftbeersRoute.getCraftBeerStyles)
app.post('/craftbeers', craftbeersRoute.createCraftBeer)
app.put('/craftbeers/:id', [authenticationRoute.authenticateUser, craftbeersRoute.updateCraftBeer]) // Restricted
app.delete('/craftbeer/:id', [authenticationRoute.authenticateUser, craftbeersRoute.deleteCraftBeer]) // Restricted

// 
// Craft Brewery Table
//
app.get('/craftbreweries/limit/:limit/:offset', craftbreweriesRoute.getCraftBreweries)
app.get('/craftbreweries/id/:id', craftbreweriesRoute.getCraftBreweriesByID)
app.get('/craftbreweries/search/:name', craftbreweriesRoute.getCraftBreweriesByName)
app.get('/craftbreweries', craftbreweriesRoute.getCraftBreweriesAll)
app.post('/craftbreweries', craftbreweriesRoute.createCraftBreweries)
app.put('/craftbreweries/:id', [authenticationRoute.authenticateUser, craftbreweriesRoute.updateCraftBrewery]) // Restricted
app.delete('/craftbreweries/:id', [authenticationRoute.authenticateUser, craftbreweriesRoute.deleteCraftBrewery]) // Restricted

// 
// Users Table
// 
app.get('/users', usersRoute.getUsers)
app.post('/users', usersRoute.createUser)
app.put('/users', [authenticationRoute.authenticateUser, usersRoute.updateCurrentUser]) // Restricted
app.delete('/users', [authenticationRoute.authenticateUser, usersRoute.deleteCurrentUser]) // Restricted

app.get('/users/:username', usersRoute.getUserByUsername)
app.put('/users/:username', [authenticationRoute.authenticateUser, usersRoute.updateUser]) // Restricted (admin)
app.delete('/users/:username', [authenticationRoute.authenticateUser, usersRoute.deleteUser]) // Restricted (admin)

// 
// User Favorites Table
// 
app.get('/userfavorites/:id/:beer_id', userfavoriteRoute.createUserFavorite)
app.get('/userfavorites/:id', userfavoriteRoute.getUserFavoritesID)
app.get('/userfavorites', userfavoriteRoute.getUserFavorites)


app.listen(port, () => {
    console.log(`App running on port ${port}.`)
})
