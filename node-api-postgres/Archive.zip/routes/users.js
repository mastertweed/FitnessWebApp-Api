const db = require('../db/db')

// USERS Functions
//
const getUsers = (request, response) => {
    db.query('SELECT * FROM users ORDER BY user_id ASC', (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getUserByUsername = (request, response) => {
    const username = request.params.username

    db.query('SELECT * FROM users WHERE username = $1', [username], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

// Create user, userinfo and preference all at once (maybe stored procedure)
const createUser = (request, response) => {
    const { username, password } = request.body

    db.query('INSERT INTO users(username, password) VALUES ($1, $2)', [username, password], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(201).send('User added!')
    })
}

const updateCurrentUser = (request, response) => {
    const username = request.username
    const { username_updated, password } = request.body

    db.query(
        'UPDATE users SET username = $1, password = $2 WHERE username = $3', [username_updated, password, username],
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).send('User modified with username: ${username}')
        }
    )
}

const deleteCurrentUser = (request, response) => {
    const username = request.username

    db.query('DELETE FROM users WHERE username = $1', [username], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).send('User deleted with username: ${username}')
    })
}

// Admin functions
const updateUser = (request, response) => {
    const username = request.params.username
    const { username_updated, password } = request.body

    db.query(
        'UPDATE users SET username = $1, password = $2 WHERE username = $3', [username_updated, password, username],
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).send('User modified with username: ${username}')
        }
    )
}

const deleteUser = (request, response) => {
    const username = request.params.username

    db.query('DELETE FROM users WHERE username = $1', [username], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).send('User deleted with username: ${username}')
    })
}

module.exports = {
    getUsers,
    getUserByUsername,
    createUser,
    updateCurrentUser,
    deleteCurrentUser,
    updateUser,
    deleteUser
}