const db = require('../db/db')

// Searching Functions
//

const getUserFavorites = (request, response) => {

    db.query('SELECT * FROM userfavorites', 
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).json(results.rows)
        })
}

const getUserFavoritesID = (request, response) => {
    let id = request.params.id

    db.query('SELECT * FROM userfavorites WHERE user_id = $1', [id], 
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).json(results.rows)
        })
}

const createUserFavorite = (request, response) => {
    let user_id = request.params.user_id
    let beer_id = request.params.beer_id

    db.query('INSERT INTO userfavorites (user_id, beer_id) VALUES ($1, $2)', [user_id, beer_id], 
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(201)
        })
}

module.exports = {
    getUserFavorites,
    getUserFavoritesID,
    createUserFavorite
}