const { request, response } = require('express')
const db = require('../db/db')

// USERS Functions
//
const getCraftBeersAll = (request, response) => {
    db.query('SELECT * FROM craftbeers ORDER BY id ASC', (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBeers = (request, response) => {
    const row_count = request.params.limit
    const row_to_skip = request.params.offset

    db.query('SELECT * FROM craftbeers ORDER BY id ASC LIMIT $1 OFFSET $2', [row_count, row_to_skip], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}


const getCraftBeerByID = (request, response) => {
    const id = request.params.id

    db.query('SELECT * FROM craftbeers WHERE id = $1', [id], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBeerByName = (request, response) => {
    let name = request.params.name
    let searchName = ''
    for (let i = 0; i < name.length; i++) {
        searchName = searchName + '(' + name[i].toUpperCase() + '|' + name[i].toLowerCase() + ')' 
    }

    searchName = '%' + searchName + '%'

    console.log(searchName)

    db.query('SELECT * FROM craftbeers WHERE name SIMILAR TO $1 LIMIT 100', [searchName], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBeerStyles = (request,response) => {
    db.query('SELECT DISTINCT(style) FROM craftbeers WHERE style != \'NULL\' ORDER BY style', (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

// Create user, userinfo and preference all at once (maybe stored procedure)
const createCraftBeer = (request, response) => {
    const { abv, ibu, id_num, name, style, brewery_id, ounces, rating } = request.body

    db.query('INSERT INTO craftbeers(abv, ibu, id_num, name, style, brewery_id, ounces, rating) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)', 
        [abv, ibu, id_num, name, style, brewery_id, ounces], 
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(201).send('Craft Beer added!')
        }
    )
}

// Admin functions
const updateCraftBeer = (request, response) => {
    const id = request.params.id
    const { abv, ibu, id_num, name, style, brewery_id, ounces, rating } = request.body

    db.query(
        'UPDATE craftbeers SET abv = $1, ibu = $2, id_num = $3, name = $4, style = $5, brewery_id = $6, ounces = $7, rating = $8 WHERE id = $9', 
        [abv, ibu, id_num, name, style, brewery_id, ounces, rating, id],
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).send('User modified with Email: ${email}')
        }
    )
}

const deleteCraftBeer = (request, response) => {
    const id = request.params.id

    db.query('DELETE FROM craftbeers WHERE id = $1', [id], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).send('Craft Beer deleted with ID: ${id}')
    })
}

module.exports = {
    getCraftBeersAll,
    getCraftBeers,
    getCraftBeerByID,
    getCraftBeerByName,
    getCraftBeerStyles,
    createCraftBeer,
    updateCraftBeer,
    deleteCraftBeer
}