const db = require('../db/db')

// Searching Functions
//

const getBeerBrewerySearch = (request, response) => {
    let term = request.params.term
    let searchName = ''
    for (let i = 0; i < term.length; i++) {
        searchName = searchName + '(' + term[i].toUpperCase() + '|' + term[i].toLowerCase() + ')' 
    }

    searchName = '%' + searchName + '%'

    db.query('SELECT craftbeers.id, craftbeers.name as beer_name, craftbreweries.name as brewery_name, ' +
            'abv, ibu, style, ounces, craftbeers.rating as beer_rating ' +
            'FROM craftbeers, craftbreweries ' +
            'WHERE craftbeers.name SIMILAR TO $1 AND ' +
            'craftbeers.brewery_id = craftbreweries.id ' +
            'LIMIT 100', [searchName], 
            (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}


module.exports = {
    getBeerBrewerySearch
}