const db = require('../db/db')

// USERS Functions
//
const getCraftBreweriesAll = (request, response) => {
    db.query('SELECT * FROM craftbreweries ORDER BY id ASC', (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBreweries = (request, response) => {
    const row_count = request.params.limit
    const row_to_skip = request.params.offset

    db.query('SELECT * FROM craftbreweries ORDER BY id ASC LIMIT $1 OFFSET $2', [row_count, row_to_skip], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBreweriesByID = (request, response) => {
    const id = request.params.id

    db.query('SELECT * FROM craftbreweries WHERE id = $1', [id], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

const getCraftBreweriesByName = (request, response) => {
    const name = request.params.name

    db.query('SELECT * FROM craftbreweries WHERE name = $1', [name], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).json(results.rows)
    })
}

// Create user, userinfo and preference all at once (maybe stored procedure)
const createCraftBreweries = (request, response) => {
    const { name, city, state } = request.body

    db.query('INSERT INTO craftbreweries(name, city, state) VALUES ($1, $2, $3)', [name, city, state], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(201).send('Craft Brewery added!')
    })
}

// Admin functions
const updateCraftBrewery = (request, response) => {
    const id = request.params.id
    const { name, city, state } = request.body

    db.query(
        'UPDATE craftbreweries SET name = $1, city = $2, state = $3 WHERE id = $4', [name, city, state, id],
        (err, results) => {
            if (err) {
                return response.status(404).send(err)
            }
            response.status(200).send('User modified with Email: ${email}')
        }
    )
}

const deleteCraftBrewery = (request, response) => {
    const id = request.params.id

    db.query('DELETE FROM craftbreweries WHERE id = $1', [id], (err, results) => {
        if (err) {
            return response.status(404).send(err)
        }
        response.status(200).send('User deleted with Email: ${email}')
    })
}

module.exports = {
    getCraftBreweriesAll,
    getCraftBreweries,
    getCraftBreweriesByID,
    getCraftBreweriesByName,
    createCraftBreweries,
    updateCraftBrewery,
    deleteCraftBrewery
}